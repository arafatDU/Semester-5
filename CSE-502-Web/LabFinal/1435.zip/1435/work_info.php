<?php include 'db_config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Work Info</title>
    <link rel="stylesheet" href="1435.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    
    <div class="mainContent">
        <div class="container2">
            <h1>Work Experience</h1>
            <div class="table">

                <table border="1">
                    <tr><th>Company</th><th>Role</th><th>Years</th></tr>
                    <tr><td>Itransition</td><td>Intern Software Developer</td><td>2024 - Present</td></tr>
                    <tr><td>Udvash</td><td>Teacher</td><td>2022 - 2023</td></tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
