<?php
session_start();
include 'db_config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="1435.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    <div class="mainContent">
        <h1>Welcome to My Website</h1>
        <br>
        <h2>I'm Arafat Hussain!<br>
           A Full Stack Web Developer From Bangladesh.</h2>
    </div>
</body>
</html>
