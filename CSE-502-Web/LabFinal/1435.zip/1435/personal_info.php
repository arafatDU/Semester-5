<?php include 'db_config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Personal Info</title>
    <link rel="stylesheet" href="1435.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    

    <div class="mainContent">
        <div class="container2">
            <h1>Personal Information</h1>
            <div class="table">

                <table border="1">
                    <tr><th>First Name</th><td>Munshi Md. Arafat</td></tr>
                    <tr><th>Last Name</th><td>Hussain</td></tr>
                    <tr><th>Father's Name</th><td>Munshi A. Razzak</td></tr>
                    <tr><th>Mother's Name</th><td>Mrs. Sheuli Akter</td></tr>
                    <tr><th>Address</th><td>26/1 Arjotpara, Mohakhali, Dhaka</td></tr>
                    <tr><th>Phone</th><td>+8801770679342</td></tr>
                    <tr><th>Email</th><td>arafat.du.iit@gmail.com</td></tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
