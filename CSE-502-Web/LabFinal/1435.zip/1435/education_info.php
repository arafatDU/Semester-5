<?php include 'db_config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Education Info</title>
    <link rel="stylesheet" href="1435.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    <div class="mainContent">
        <div class="container2">

            <h1>Education Information</h1>
            <div class="table">

                <table border="1">
                    <tr><th>Degree</th><th>University</th><th>Year</th></tr>
                    <tr><td>Bachelor's in Software Engineering</td><td>University of Dhaka</td><td>2026</td></tr>
                    <tr><td>High School</td><td>BAF Shaheen College Dhaka</td><td>2019</td></tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
